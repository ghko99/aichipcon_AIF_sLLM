// 통합공공임대 유형 판별 함수 --> ok
function isEligibleForPublicRental(customerInfo) {
    // 고객 정보
    const {
        birthDate,
        enrolledUniversity,
        jobSeeking,
        familyMembersCount,
        married,
        marriageDate,
        dualIncome,
        hasChildren,
        childrenCount,
        youngestChildBirthDate,
        singleParent,
        monthlyIncome,
        householdMonthlyIncome,
        ownHouse,
        assets,
        ownCar,
        carPrice,
        hasSubscriptionAccount,
        subscriptionStartDate,
        subscriptionPaymentCount,
        subscriptionPaymentAmount,
    } = customerInfo;
  
    // 무주택 여부 확인
    if (ownHouse) {
      return [false, "주택을 소유하고 있으므로 무주택세대구성원 자격이 없습니다."];
    }
  
    // 가구 월 평균 소득 기준 확인
    const medianIncomeThresholds = {
      1: 2228445,
      2: 3682609,
      3: 4714657,
      4: 5729913,
      5: 6695735,
      6: 7618369,
      7: 8514994,
      8: 9411619,
    };
  
    let medianIncomeThreshold;
    if (familyMembersCount in medianIncomeThresholds) {
      medianIncomeThreshold = medianIncomeThresholds[familyMembersCount];
    } else {
      medianIncomeThreshold = medianIncomeThresholds[8] + (familyMembersCount - 8) * 879534;
    }
  
    if (householdMonthlyIncome > medianIncomeThreshold * 1.5) {
      return [false, "가구 월 평균 소득이 기준 중위소득의 150%를 초과합니다."];
    }
  
    // 총자산 보유 기준 확인 (34,500만원 이하)
    if (assets > 345000000) {
      return [false, "총 자산 보유 기준을 초과합니다. (34,500만원 이하)"];
    }
  
    // 자동차 가액 기준 확인 (3,708만원 이하)
    if (ownCar && carPrice > 37080000) {
      return [false, "자동차 가액 기준을 초과합니다. (3,708만원 이하)"];
    }
     
    return [true, "통합공공임대 자격 요건을 충족합니다."];
}

// 통합공공임대(신혼희망) 유형 판별 함수 --> 우선 ok, 일반 검토 필요
function isEligibleForPublicRentalNewlyWed(customerInfo) {
    // 고객 정보
    const {
        birthDate,
        enrolledUniversity,
        jobSeeking,
        familyMembersCount,
        married,
        marriageDate,
        dualIncome,
        hasChildren,
        childrenCount,
        youngestChildBirthDate,
        singleParent,
        monthlyIncome,
        householdMonthlyIncome,
        ownHouse,
        assets,
        ownCar,
        carPrice,
        hasSubscriptionAccount,
        subscriptionStartDate,
        subscriptionPaymentCount,
        subscriptionPaymentAmount,
    } = customerInfo;
  
    // 무주택 여부 확인
    if (ownHouse) {
      return [false, "주택을 소유하고 있으므로 무주택세대구성원 자격이 없습니다."];
    }
  
    // 혼인 상태 및 기간 조건 확인 (혼인 중이며, 혼인 기간 7년 이내 또는 예비 신혼부부)
    const currentYear = new Date().getFullYear();
    const marriageYear = new Date(marriageDate).getFullYear();
    const marriageDuration = currentYear - marriageYear;
  
    if (!married || marriageDuration > 7) {
        return [false, "혼인 상태이거나 혼인 기간이 7년을 초과하여 신혼부부 자격이 없습니다."];
    }
  
    // 만 6세 이하 자녀 여부 확인
    if (hasChildren) {
        const youngestChildYear = new Date(youngestChildBirthDate).getFullYear();
        const youngestChildAge = currentYear - youngestChildYear;
        if (youngestChildAge > 6) {
            return [false, "만 6세 이하 자녀가 없으므로 신혼부부 자격이 없습니다."];
        }
    }
  
    // 가구 월 평균 소득 기준 확인 (기준 중위소득의 100% 이하, 2인 가구는 110%)
    const medianIncomeThresholds = {
        1: 2228445,
        2: 3682609 * 1.1,  // 2인 가구는 110%
        3: 4714657,
        4: 5729913,
        5: 6695735,
        6: 7618369,
        7: 8514994,
        8: 9411619,
    };
  
    let medianIncomeThreshold;
    if (familyMembersCount in medianIncomeThresholds) {
        medianIncomeThreshold = medianIncomeThresholds[familyMembersCount];
    } else {
        medianIncomeThreshold = medianIncomeThresholds[8] + (familyMembersCount - 8) * 879534;
    }
  
    if (householdMonthlyIncome > medianIncomeThreshold) {
        return [false, "가구 월 평균 소득이 기준 중위소득을 초과합니다."];
    }
  
    // 총자산 보유 기준 확인 (34,500만원 이하)
    if (assets > 345000000) {
        return [false, "총 자산 보유 기준을 초과합니다. (34,500만원 이하)"];
    }
  
    // 자동차 가액 기준 확인 (3,708만원 이하)
    if (ownCar && carPrice > 37080000) {
        return [false, "자동차 가액 기준을 초과합니다. (3,708만원 이하)"];
    }
     
    return [true, "통합공공임대(신혼희망) 자격 요건을 충족합니다."];
}

// 국민임대 유형 판별 함수
function isEligibleForNationalRental(customerInfo) {
    // 고객 정보
    const {
        birthDate,
        enrolledUniversity,
        jobSeeking,
        familyMembersCount,
        married,
        marriageDate,
        dualIncome,
        hasChildren,
        childrenCount,
        youngestChildBirthDate,
        singleParent,
        monthlyIncome,
        householdMonthlyIncome,
        ownHouse,
        assets,
        ownCar,
        carPrice,
        hasSubscriptionAccount,
        subscriptionStartDate,
        subscriptionPaymentCount,
        subscriptionPaymentAmount,
    } = customerInfo;

    // 무주택 여부 확인
    if (ownHouse) {
        return [false, "주택을 소유하고 있으므로 무주택세대구성원 자격이 없습니다."];
    }

    // 가구 월 평균 소득 기준 확인 (전년도 도시 근로자 가구원수별 월평균 소득의 70% 이하)
    const incomeThresholds = {
        1: 3134668,  // 1인가구
        2: 4332570,  // 2인가구
        3: 5039054,  // 3인가구
        4: 5773927,  // 4인가구
        5: 6142550,  // 5인가구
        6: 6694297,  // 6인가구
        7: 7246045,  // 7인가구
        8: 7797793,  // 8인가구
    };

    let incomeThreshold;
    if (familyMembersCount in incomeThresholds) {
        incomeThreshold = incomeThresholds[familyMembersCount];
    } else {
        incomeThreshold = incomeThresholds[8] + (familyMembersCount - 8) * 879534;
    }

    if (householdMonthlyIncome > incomeThreshold) {
        return [false, "가구 월 평균 소득이 국민임대 기준 소득을 초과합니다."];
    }

    // 총자산 보유 기준 확인 (34,500만원 이하)
    if (assets > 345000000) {
        return [false, "총 자산 보유 기준을 초과합니다. (34,500만원 이하)"];
    }

    // 자동차 가액 기준 확인 (3,708만원 이하)
    if (ownCar && carPrice > 37080000) {
        return [false, "자동차 가액 기준을 초과합니다. (3,708만원 이하)"];
    }

    return [true, "국민임대 자격 요건을 충족합니다."];
}

// 공공임대 유형 판별 함수
function isEligibleForPublicRental(customerInfo) {
    // 고객 정보
    const {
        birthDate,
        enrolledUniversity,
        jobSeeking,
        familyMembersCount,
        married,
        marriageDate,
        dualIncome,
        hasChildren,
        childrenCount,
        youngestChildBirthDate,
        singleParent,
        monthlyIncome,
        householdMonthlyIncome,
        ownHouse,
        assets,
        ownCar,
        carPrice,
        hasSubscriptionAccount,
        subscriptionStartDate,
        subscriptionPaymentCount,
        subscriptionPaymentAmount,
    } = customerInfo;

    // 무주택 여부 확인
    if (ownHouse) {
        return [false, "주택을 소유하고 있으므로 무주택세대구성원 자격이 없습니다."];
    }

    // 청약 통장 가입 여부 및 납입 조건 확인
    if (!hasSubscriptionAccount) {
        return [false, "청약 통장을 소유하고 있지 않습니다."];
    }

    // 청약 통장 가입 기간 및 납입 횟수 확인 (최소 6개월 경과 및 6회 납입 필요)
    const subscriptionMinDate = new Date();
    subscriptionMinDate.setMonth(subscriptionMinDate.getMonth() - 6);
    if (new Date(subscriptionStartDate) > subscriptionMinDate) {
        return [false, "청약 통장 가입 기간이 6개월 미만입니다."];
    }
    if (subscriptionPaymentCount < 6) {
        return [false, "청약 통장 납입 횟수가 6회 미만입니다."];
    }

    // 자산 보유 기준 확인
    if (assets > 215500000) {
        return [false, "부동산 자산 보유 기준을 초과합니다. (215,500천 원 이하)"];
    }

    // 자동차 가액 기준 확인 (36,830천 원 이하)
    if (ownCar && carPrice > 36830000) {
        return [false, "자동차 가액 기준을 초과합니다. (36,830천 원 이하)"];
    }

    return [true, "공공임대 자격 요건을 충족합니다."];
}

// 영구임대 유형 판별 함수 --> 다시 한 번 검토 필요 (특수 조건이 너무 많음)
function isEligibleForPermanentRental(customerInfo) {
    // 고객 정보
    const {
      ownHouse,
      householdMonthlyIncome,
      familyMembersCount,
      singleParent,
    } = customerInfo;
  
    // 무주택 여부 확인
    if (ownHouse) {
      return [false, "주택을 소유하고 있으므로 무주택세대구성원 자격이 없습니다."];
    }
  
    // 한부모가족 여부 확인 (추가 조건이 없는 경우)
    if (singleParent) {
      return [true, "한부모가족으로서 영구임대 자격 요건을 충족합니다."];
    }
  
    return [false, "영구임대 자격 요건을 충족하지 않습니다."];
}

// 행복주택 유형 판별 함수
function isEligibleForHappyHouse(customerInfo) {
    // 고객 정보
    const {
        familyMembersCount,
        householdMonthlyIncome,
        ownHouse,
        assets,
        ownCar,
        carPrice,
        enrolledUniversity,
        dualIncome,
    } = customerInfo;

    // 무주택 여부 확인
    if (ownHouse) {
        return [false, "주택을 소유하고 있으므로 무주택세대구성원 자격이 없습니다."];
    }

    // 소득 기준 확인 (전년도 도시근로자 가구원수별 월평균 소득 100%)
    const incomeThresholds = {
        1: 6509452, // 1인가구 기준
        2: 7622056, // 2인가구 기준
        3: 7198649, // 3인가구 기준
        4: 7622056,
        5: 8040492,
        6: 8701639,
        7: 9362786,
        8: 10023933,
    };

    let incomeThreshold;
    if (familyMembersCount in incomeThresholds) {
        incomeThreshold = incomeThresholds[familyMembersCount];
    } else {
        return [false, "가구원 수에 대한 소득 기준을 충족하지 못합니다."];
    }

    // 대학생 또는 세대원 청년인 경우 소득 기준 120%까지 허용
    if (enrolledUniversity) {
        incomeThreshold *= 1.2;
    }

    // 맞벌이 가구의 경우 소득 기준 120%까지 허용
    if (dualIncome) {
        incomeThreshold *= 1.2;
    }

    if (householdMonthlyIncome > incomeThreshold) {
        return [false, "가구 월 평균 소득이 기준을 초과합니다."];
    }

    // 자산 보유 기준 확인 (34,500만원 이하)
    if (assets > 345000000) {
        return [false, "총 자산 보유 기준을 초과합니다. (34,500만원 이하)"];
    }

    // 자동차 가액 기준 확인 (3,708만원 이하)
    if (ownCar && carPrice > 37080000) {
        return [false, "자동차 가액 기준을 초과합니다. (3,708만원 이하)"];
    }

    return [true, "행복주택 자격 요건을 충족합니다."];
}

// 행복주택(신혼희망) 유형 판별 함수
function isEligibleForHappyHousingForNewlyweds(customerInfo) {
    // 고객 정보
    const {
        married,
        marriageDate,
        hasChildren,
        youngestChildBirthDate,
        ownHouse,
        householdMonthlyIncome,
        dualIncome,
        familyMembersCount
    } = customerInfo;

    // 무주택 여부 확인
    if (ownHouse) {
        return [false, "주택을 소유하고 있으므로 무주택세대구성원 자격이 없습니다."];
    }

    // 신혼부부 조건 확인
    const currentDate = new Date();
    const marriageDateObj = new Date(marriageDate);
    const marriageDuration = (currentDate - marriageDateObj) / (1000 * 60 * 60 * 24 * 365); // 혼인 기간(년)

    const youngestChildAge = (currentDate - new Date(youngestChildBirthDate)) / (1000 * 60 * 60 * 24 * 365); // 가장 어린 자녀의 나이(년)

    if (!(married && (marriageDuration <= 7 || (hasChildren && youngestChildAge <= 6)))) {
        return [false, "신혼부부 조건을 만족하지 않습니다."];
    }

    // 소득 기준 확인
    const incomeThresholds = {
        1: 3482964,
        2: 5415712,
        3: 7198649,
        4: 8248467,
        5: 8775071,
        6: 9563282,
        7: 10351493,
        8: 11139704,
    };

    let incomeThreshold;
    if (familyMembersCount in incomeThresholds) {
        incomeThreshold = incomeThresholds[familyMembersCount];
    } else {
        return [false, "가구원 수에 대한 소득 기준을 찾을 수 없습니다."];
    }

    // 맞벌이 여부에 따른 소득 기준 조정
    if (dualIncome) {
        incomeThreshold *= 1.2;
    }

    if (householdMonthlyIncome > incomeThreshold) {
        return [false, "가구 월평균 소득 기준을 초과합니다."];
    }

    return [true, "행복주택(신혼희망) 자격 요건을 충족합니다."];
}

// 장기전세 유형 판별 함수
function isEligibleForLongTermJeonse(customerInfo) {
    // 고객 정보
    const {
        birthDate,
        familyMembersCount,
        married,
        monthlyIncome,
        householdMonthlyIncome,
        ownHouse,
        assets,
        ownCar,
        carPrice,
    } = customerInfo;

    // 무주택 여부 확인
    if (ownHouse) {
        return [false, "주택을 소유하고 있으므로 무주택세대구성원 자격이 없습니다."];
    }

    // 가구 월 평균 소득 기준 확인 (전용면적별로 다름)
    const incomeThresholdBelow60 = 6772599; // 2023년 도시근로자 가구당 월평균 소득의 100%
    const incomeThresholdAbove60 = incomeThresholdBelow60 * 1.2; // 120%

    if (householdMonthlyIncome > incomeThresholdAbove60) {
        return [false, "가구 월 평균 소득이 장기전세 기준 소득을 초과합니다."];
    }

    // 전용면적 60㎡ 이하 기준 (100%) 또는 전용면적 60㎡ 초과 기준 (120%) 중 하나 만족하면 적합
    const isEligibleForAreaBelow60 = householdMonthlyIncome <= incomeThresholdBelow60;
    const isEligibleForAreaAbove60 = householdMonthlyIncome <= incomeThresholdAbove60;

    if (!isEligibleForAreaBelow60 && !isEligibleForAreaAbove60) {
        return [false, "가구 월 평균 소득이 장기전세 기준 소득을 초과합니다."];
    }

    // 총자산 보유 기준 확인 (총 3억 2500만 원 이하)
    if (assets > 325000000) {
        return [false, "총 자산 보유 기준을 초과합니다. (3억 2,500만 원 이하)"];
    }

    // 자동차 현재가치 기준 확인 (3,496만 원 이하)
    if (ownCar && carPrice > 34960000) {
        return [false, "자동차 가액 기준을 초과합니다. (3,496만 원 이하)"];
    }

    return [true, "장기전세 자격 요건을 충족합니다."];
}

// 신축다세대매입임대 --> 정보 X
















// 가정어린이집 --> 정보 X















// 일반매입임대 입주 자격 판별 함수 --> 검토 필요
function isEligibleForGeneralRental(customerInfo) {
    // 고객 정보
    const {
        familyMembersCount,
        householdMonthlyIncome,
        ownHouse,
        assets,
        ownCar,
        carPrice,
    } = customerInfo;

    // 무주택 여부 확인
    if (ownHouse) {
        return [false, "주택을 소유하고 있으므로 무주택세대구성원 자격이 없습니다."];
    }

    // 소득 기준 확인
    const incomeThreshold = {
        "1순위": 0.7, // 월평균 소득 70% 이하
        "2순위": 0.5, // 월평균 소득 50% 이하
    };
    const lastYearIncome = {
        1: 3134668,
        2: 4332570,
        3: 5039054,
        4: 5773927,
        5: 6142550,
        6: 6694297,
        7: 7246045,
        8: 7797793,
    };

    let applicableIncomeThreshold = incomeThreshold["2순위"];
    if (familyMembersCount in lastYearIncome) {
        if (householdMonthlyIncome > lastYearIncome[familyMembersCount] * incomeThreshold["1순위"]) {
            return [false, "월평균 소득이 1순위 소득 기준을 초과합니다."];
        } else if (householdMonthlyIncome > lastYearIncome[familyMembersCount] * incomeThreshold["2순위"]) {
            applicableIncomeThreshold = incomeThreshold["1순위"];
        }
    } else {
        return [false, "가구원 수에 대한 소득 기준을 판별할 수 없습니다."];
    }

    // 자산 기준 확인
    const assetLimit = 241000000; // 자산 24,100만원 이하
    const carPriceLimit = 37080000; // 자동차 현재가치 3,708만원 이하

    if (assets > assetLimit) {
        return [false, "총 자산 보유 기준을 초과합니다. (자산 24,100만원 이하)"];
    }

    if (ownCar && carPrice > carPriceLimit) {
        return [false, "자동차 가액 기준을 초과합니다. (3,708만원 이하)"];
    }

    return [true, `일반 매입임대 자격 요건을 충족합니다. ${applicableIncomeThreshold === incomeThreshold["1순위"] ? "1순위" : "2순위"} 자격입니다.`];
}

// 기존주택전세임대 판별 함수 --> 검토 필요
function isEligibleForExistingRental2ndRank(customerInfo) {
    // 고객 정보
    const {
        singleParent, // 한부모 여부
        householdMonthlyIncome, // 가구 월 평균 소득
    } = customerInfo;

    // 전년도 도시근로자 가구당 월평균 소득의 50% 기준 (예시 값, 필요시 업데이트 필요)
    const medianIncome50 = 3000000; // 단위: 원, 이 값은 제공된 이미지를 참고하여 정확히 설정해야 합니다.

    // 한부모가족 여부 확인
    if (singleParent) {
        return [true, "한부모가족으로 기존주택전세임대 2순위 입주 자격을 충족합니다."];
    }

    // 월평균 소득 50% 이하 여부 확인
    if (householdMonthlyIncome <= medianIncome50) {
        return [true, "월평균 소득이 기준 이하로 기존주택전세임대 2순위 입주 자격을 충족합니다."];
    }

    // 해당 조건을 모두 충족하지 않는 경우
    return [false, "한부모가족이 아니며, 소득 기준을 충족하지 않아 기존주택전세임대 입주 자격을 충족하지 않습니다."];
}

// 집주인임대 입주 자격 판별 함수
function isEligibleForOwnerRental(customerInfo) {
    const {
      birthDate,
      householdMonthlyIncome,
      married,
      marriageDate,
      familyMembersCount,
    } = customerInfo;
    
    const currentYear = new Date().getFullYear();
    const birthYear = new Date(birthDate).getFullYear();
    const marriageYear = marriageDate ? new Date(marriageDate).getFullYear() : null;
    
    const age = currentYear - birthYear;
    const isYouth = age >= 19 && age <= 39;
    const isSenior = age >= 65;
    const isNewlywed = married && marriageYear && currentYear - marriageYear <= 7;
    
    // 월평균소득 120% 기준
    const incomeThresholds = {
      1: 3134668 * 1.2,
      2: 4332570 * 1.2,
      3: 5039054 * 1.2,
      4: 5773927 * 1.2,
      5: 6142550 * 1.2,
      6: 6694297 * 1.2,
      7: 7246045 * 1.2,
      8: 7797793 * 1.2,
    };
    
    const incomeThreshold = familyMembersCount in incomeThresholds
      ? incomeThresholds[familyMembersCount]
      : incomeThresholds[8];
    
    // 청년 조건 확인
    if (isYouth && householdMonthlyIncome <= incomeThreshold) {
      return [true, "집주인매입임대 청년 자격 요건을 충족합니다."];
    }
    
    // 신혼부부 조건 확인
    if (isNewlywed && householdMonthlyIncome <= incomeThreshold) {
      return [true, "집주인매입임대 신혼부부 자격 요건을 충족합니다."];
    }
    
      // 고령자 조건 확인
    if (isSenior && householdMonthlyIncome <= incomeThreshold) {
      return [true, "집주인매입임대 고령자 자격 요건을 충족합니다."];
    }
    
    return [false, "집주인매입임대 자격 요건을 충족하지 않습니다."];
  }

  





//----------------------------------------------------------------------------------------------------------//
// 고객 정보 입력 예시
const customerInfo = {
    // 개인 정보
    birthDate: "1997-10-14", // 생년월일
    enrolledUniversity: false, // 대학생 여부
    jobSeeking: true, // 취업준비생 여부
  
    // 가족 정보
    familyMembersCount: 4, // 가족 구성원 수
    married: true, // 혼인 여부
    marriageDate: "2019-11-01", // 혼인 신고 또는 혼인 예정일
    dualIncome: false, // 맞벌이 여부
    hasChildren: true, // 자녀 유무
    childrenCount: 2, // 자녀 수
    youngestChildBirthDate: "2023-10-09", // 가장 어린 자녀의 생년월일
    singleParent: false, // 한부모 여부
  
    // 소득 정보
    monthlyIncome: 1660000, // 월 평균 소득 (단위: 원)
    householdMonthlyIncome: 4160000, // 가구 월 평균 소득 (단위: 원)
    ownHouse: false, // 주택 소유 여부
  
    // 자산 정보
    assets: 60000000, // 총 자산 (단위: 원)
    ownCar: true, // 자동차 소유 여부
    carPrice: 30000000, // 자동차 가격 (단위: 원)
  
    // 청약 통장 정보
    hasSubscriptionAccount: true, // 청약 통장 소유 여부
    subscriptionStartDate: "2020-10-09", // 청약 통장 가입 일자
    subscriptionPaymentCount: 30, // 청약 통장 납입 횟수
    subscriptionPaymentAmount: 10000000, // 청약 통장 납입 금액 (단위: 원)
};  
  
// 통합공공임대 자격 여부 판단
const [integratedPublicEligible, integratedPublicMessage] = isEligibleForPublicRental(customerInfo);
console.log(publicMessage);

// 통합공공임대(신혼희망) 자격 여부 판단
const [integratedPublicEligibleNewlyWed, integratedPublicMessageNewlyWed] = isEligibleForPublicRentalNewlyWed(customerInfo);
console.log(publicMessage);

// 국민임대 자격 여부 판단
const [nationalEligible, nationalMessage] = isEligibleForNationalRental(customerInfo);
console.log(nationalMessage);

// 공공임대 자격 여부 판단
const [publicEligible, publicMessage] = isEligibleForPublicRental(customerInfo);
console.log(publicMessage);

// 영구임대 자격 여부 판단
const [permanentEligible, permanentMessage] = isEligibleForPermanentRental(customerInfo);
console.log(permanentMessage);

// 행복주택 자격 여부 판단
const [happyHouseEligible, happyHouseMessage] = isEligibleForHappyHouse(customerInfo);
console.log(happyHouseMessage);

// 행복주택(신혼희망) 자격 여부 판단
const [happyEligibleNewlyWed, happyMessageNewlyWed] = isEligibleForHappyHousingForNewlyweds(customerInfo);
console.log(happyMessage);

// 장기전세 자격 여부 판단
const [longTermJeonseEligible, longTermJeonseMessage] = isEligibleForLongTermJeonse(customerInfo);
console.log(message);

// 신축다세대매입 자격 여부 판단

// 가정어린이집 자격 여부 판단

// 일반 매입임대 자격 여부 판단
const [purchaseEligible, purchaseMessage] = isEligibleForGeneralRental(customerInfo);
console.log(message);

// 기존주택전세임대 자격 여부 판단
const [exsistHouseEligible, exsistHouseMessage] = isEligibleForExistingRental2ndRank(customerInfo);
console.log(eligibilityMessage);

// 집주인매입임대 자격 여부 판단
const [ownerRentalEligible, ownerRentalMessage] = isEligibleForOwnerRental(customerInfo);
console.log(ownerRentalMessage);


//------------------------------------------------------------------------------------------------------//
// 각 자격 여부를 확인하고 적합한 임대 유형을 추가
if (integratedPublicEligible) eligibleRentalTypes.push("통합공공임대");
if (integratedPublicEligibleNewlyWed) eligibleRentalTypes.push("통합공공임대(신혼희망)");
if (nationalEligible) eligibleRentalTypes.push("국민임대");
if (publicEligible) eligibleRentalTypes.push("공공임대");
if (permanentEligible) eligibleRentalTypes.push("영구임대");
if (happyEligible) eligibleRentalTypes.push("행복주택");
if (happyEligibleNewlyWed) eligibleRentalTypes.push("행복주택(신혼희망)");
if (longTermJeonseEligible) eligibleRentalTypes.push("장기전세");
// 신축다세대매입임대
// 가정어린이집
if (purchaseEligible) eligibleRentalTypes.push("일반매입임대");
if (exsistHouseEligible) eligibleRentalTypes.push("기존주택전세임대");
if (ownerRentalEligible) eligibleRentalTypes.push("집주인임대");

// 최종 결과 출력
if (eligibleRentalTypes.length > 0) {
  console.log("고객님께 적합한 임대 유형은 다음과 같습니다:");
  eligibleRentalTypes.forEach((rentalType) => console.log("- " + rentalType));
} else {
  console.log("고객님께 적합한 임대 유형이 없습니다.");
}
